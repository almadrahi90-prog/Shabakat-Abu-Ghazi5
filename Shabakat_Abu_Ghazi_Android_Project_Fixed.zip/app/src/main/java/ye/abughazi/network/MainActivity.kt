package ye.abughazi.network

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(16, 67, 62)
        window.navigationBarColor = android.graphics.Color.rgb(16, 67, 62)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(18))
            setBackgroundColor(android.graphics.Color.rgb(245, 247, 246))
            layoutParams = ViewGroup.LayoutParams(-1, -1)
        }
        root.addView(TextView(this).apply {
            text = "شبكة أبو غازي"; textSize = 28f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setTextColor(android.graphics.Color.rgb(16, 67, 62))
            setPadding(0, dp(8), 0, dp(8))
        })
        root.addView(TextView(this).apply {
            text = "لوحة إدارة الشبكة — نسخة أولية"; textSize = 16f; gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.DKGRAY); setPadding(0, 0, 0, dp(18))
        })
        root.addView(TextView(this).apply { text = "عنوان الراوتر المحلي (IP)"; textSize = 15f })
        root.addView(EditText(this).apply {
            hint = "مثال: 192.168.88.1"; singleLine = true
            inputType = android.text.InputType.TYPE_CLASS_TEXT; setText("192.168.88.1")
        })
        val cards = listOf(
            "حالة الراوتر" to "ستظهر بعد تفعيل الاتصال",
            "مشتركو Hotspot" to "إدارة المستخدمين والكروت",
            "إنشاء كروت" to "إنشاء دفعات كروت للمشتركين",
            "الموزعون والأرصدة" to "إدارة الموزعين وحساباتهم",
            "المبيعات والمصروفات" to "تسجيل المبيعات والمصروفات",
            "اتصالا الإنترنت" to "متابعة الاتصالين وحالة الخطوط",
            "إعدادات الشبكة" to "إعدادات الإدارة والاتصال"
        )
        for ((name, desc) in cards) {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(10))
                setBackgroundColor(android.graphics.Color.WHITE)
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
                    setMargins(0, dp(5), 0, dp(5))
                }
                elevation = dp(1).toFloat()
            }
            box.addView(TextView(this).apply {
                text = name; textSize = 17f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(android.graphics.Color.rgb(16, 67, 62))
            })
            box.addView(TextView(this).apply {
                text = desc; textSize = 13f; setTextColor(android.graphics.Color.DKGRAY)
            })
            root.addView(box)
        }
        root.addView(TextView(this).apply {
            text = "تنبيه: هذه واجهة تجريبية فقط؛ لم يتم ربطها بالمايكروتك بعد. لا تدخل كلمة مرور الراوتر هنا."
            textSize = 12f; setTextColor(android.graphics.Color.rgb(150, 55, 35))
            setPadding(0, dp(12), 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
